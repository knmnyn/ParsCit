class CreateMylines < ActiveRecord::Migration
  def self.up
    create_table :mylines , :options => 'default charset=utf8' do |t|
      t.integer :l, :t, :b, :r
      t.belongs_to :para
	  t.timestamps
    end
  end

  def self.down
    drop_table :mylines
  end
end


