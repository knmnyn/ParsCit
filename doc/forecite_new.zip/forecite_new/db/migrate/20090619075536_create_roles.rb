class CreateRoles < ActiveRecord::Migration
  def self.up
    create_table :roles  , :options => 'default charset=utf8'  do |t|
      t.string :name
      t.timestamps
    end
	Role.create(:name => "Admin")
	Role.create(:name => "TrustedUser")
	Role.create(:name => "UntrustedUser")
	Role.create(:name => "Owner")
	Role.create(:name => "Annotator")
	Role.create(:name => "Reader")
  end

  def self.down
    drop_table :roles
  end
end
