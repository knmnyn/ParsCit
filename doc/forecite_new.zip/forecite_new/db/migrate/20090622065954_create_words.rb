class CreateWords < ActiveRecord::Migration
  def self.up
    create_table :words , :options => 'default charset=utf8' do |t|
      t.string :word
      t.integer :l, :t, :b, :r
      t.belongs_to :myline
	  t.belongs_to :mypage
      t.timestamps
    end
  end

  def self.down
    drop_table :words
  end
end
