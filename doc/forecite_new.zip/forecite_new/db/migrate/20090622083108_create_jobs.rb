class CreateJobs < ActiveRecord::Migration
  def self.up
    create_table :jobs, :options => 'default charset=utf8' do |t|
	  t.string :origin, :filename, :title, :tags,:tasks, :startTime, :endTime
	  t.integer :user_id, :priority, :status, :checked
	  t.timestamps
    end
  end

  def self.down
    drop_table :jobs
  end

end
