class CreateAuthorsPresentations < ActiveRecord::Migration
  def self.up
    create_table :authors_presentations, :options => 'default charset=utf8' do |t|
      t.integer :author_id, :presentation_id, :order
    end
  end

  def self.down
    drop_table :authors_presentations
  end
end
