class CreateTiddlers < ActiveRecord::Migration
  def self.up
    create_table :tiddlers , :options => 'default charset=utf8'  do |t|
	  t.string :uniqid, :modifier, :title, :tags, :tasks, :localfile, :url, :created, :modified
	  t.text   :note
      t.integer :paper_id, :fcreader, :changecount
	  t.timestamps
	end
  end

  def self.down
    drop_table :tiddlers
  end
end
