class CreateRights < ActiveRecord::Migration
  def self.up
    create_table :rights , :options => 'default charset=utf8'  do |t|
	  t.string :name, :controller, :action
      t.timestamps
    end
  end

  def self.down
    drop_table :rights
  end
end
