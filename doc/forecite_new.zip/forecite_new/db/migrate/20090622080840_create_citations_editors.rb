class CreateCitationsEditors < ActiveRecord::Migration
  def self.up
    create_table :citations_editors, :options => 'default charset=utf8' do |t|
      t.integer :editor_id, :citation_id, :order
    end
  end

  def self.down
    drop_table :citations_editors
  end
end
