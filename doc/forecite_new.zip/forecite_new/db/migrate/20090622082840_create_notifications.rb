class CreateNotifications < ActiveRecord::Migration
  def self.up
    create_table :notifications, :options => 'default charset=utf8'  do |t|
	  t.integer :job_id, :metadata, :content, :paper_id
	  t.string  :filename,:url
	  t.timestamps
    end
  end

  def self.down
    drop_table :notifications
  end
end
