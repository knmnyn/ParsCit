class CreatePresentations < ActiveRecord::Migration
  def self.up
    create_table :presentations, :options => 'default charset=utf8' do |t|

      # TODO: Any other attribs missing? (taken from Bibtex)
      t.string :address,
               :institution,
               :organization,
               :note,
               :title,
               :urls,
               :slide_images_path
               
      t.datetime :date, # TODO: what if only the month or year is specified? or no time?

      t.timestamps
    end
  end

  def self.down
    drop_table :presentations
  end
end
