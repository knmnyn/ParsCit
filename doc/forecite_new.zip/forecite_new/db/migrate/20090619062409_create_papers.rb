class CreatePapers < ActiveRecord::Migration
  def self.up
    create_table :papers, :options => 'default charset=utf8' do |t|
      t.string :address,
               :annote,
               :booktitle,
               :chapter,
               :crossref,
               :description,
			   :edition,
               :eprint,
               :howpublished,
               :institution,
               :journal,
               :key,
               :md5,
               :month,
               :note,
               :number,
               :organization,
               :pages,
               :publisher,
               :school,
               :series,
               :title,
			   :title_lower,
               :tech_type, # Bibtex "type"
               :urls,
               :volume,
               :year
	  t.text   :text
	  t.integer :last_modified_by,
	  			:level_access, #group access 0: PRIVATE, 1: GROUP_ACCESS, 2: PUBLIC
				:status  #YeeFan system 0: DEDUPLICATED, 1: PROCESSING, 2: UNTRUSTED, 3: NOT_DEDUPLICATED, 4: MANUAL_CHECKED, 5: TEMPORARY
      
	  t.timestamps
    end
  end

  def self.down
    drop_table :papers
  end
end
