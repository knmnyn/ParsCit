class CreatePresentationsPresenters < ActiveRecord::Migration
  def self.up
    create_table :presentations_presenters, :options => 'default charset=utf8' do |t|
      t.integer :presenter_id, :presentation_id, :order
    end
  end

  def self.down
    drop_table :presentations_presenters
  end
end
