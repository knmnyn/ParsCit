class CreatePapersMypages < ActiveRecord::Migration
  def self.up
    create_table :papers_mypages, :options => 'default charset=utf8' do |t|
	  t.integer :paper_id, :mypage_id, :order
      t.timestamps
    end
  end

  def self.down
    drop_table :papers_mypages
  end

end

