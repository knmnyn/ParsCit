class CreateParas < ActiveRecord::Migration
  def self.up
    create_table :paras , :options => 'default charset=utf8' do |t|
	  t.belongs_to :column
      t.integer :l, :t, :b, :r
      
      t.timestamps
    end
  end

  def self.down
    drop_table :paras
  end
end

