class CreatePeople < ActiveRecord::Migration
  def self.up
    create_table :people, :options => 'default charset=utf8' do |t|
      t.string :first_name, :middle_name, :last_name,
               :affiliation, :email, :telephone,
               :web_address, :designation, 
               :street_address, :city, :state
      t.integer :zip,
				:status

      t.timestamps
    end
  end

  def self.down
    drop_table :people
  end
end
