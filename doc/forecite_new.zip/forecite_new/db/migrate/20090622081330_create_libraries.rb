class CreateLibraries < ActiveRecord::Migration
  def self.up
    create_table :libraries, :options => 'default charset=utf8' do |t|

      t.timestamps
    end
  end

  def self.down
    drop_table :libraries
  end
end
