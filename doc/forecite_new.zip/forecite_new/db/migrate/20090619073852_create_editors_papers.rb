class CreateEditorsPapers < ActiveRecord::Migration
  def self.up
    create_table :editors_papers, :options => 'default charset=utf8' do |t|
      t.integer :editor_id, :paper_id, :order, :status
    end
  end

  def self.down
    drop_table :editors_papers
  end
end
