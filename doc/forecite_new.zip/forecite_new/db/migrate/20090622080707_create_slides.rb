class CreateSlides < ActiveRecord::Migration
  def self.up
    create_table :slides, :options => 'default charset=utf8' do |t|
      t.belongs_to :presentation

      t.string :title, :image_name, :urls
      t.text :text
      t.integer :position
      
      # TODO
      # t.belongs_to :media # cuz slides can have embedded videos, audios, images, etc

      t.timestamps
    end
  end

  def self.down
    drop_table :slides
  end
end
