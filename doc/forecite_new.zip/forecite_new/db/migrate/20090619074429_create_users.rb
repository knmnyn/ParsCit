class CreateUsers < ActiveRecord::Migration
  def self.up
    create_table :users, :options => 'default charset=utf8' do |t|
      t.belongs_to :person
      t.string :login, :hashed_password, :salt, :activation_code, :temp_pass, :image_url
	  t.integer :active, :temp_pass_active, :use_image
      t.timestamps
    end
  end

  def self.down
    drop_table :users
  end
end
