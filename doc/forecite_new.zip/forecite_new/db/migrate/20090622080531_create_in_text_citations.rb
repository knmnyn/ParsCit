class CreateInTextCitations < ActiveRecord::Migration
  def self.up
    create_table :in_text_citations, :options => 'default charset=utf8' do |t|
      t.belongs_to :citation, :paper

      t.string :context

      # TODO:
      # t.belongs_to :paragraph # in_text_citation refers to some paragraph

      t.timestamps
    end
  end

  def self.down
    drop_table :in_text_citations
  end
end
