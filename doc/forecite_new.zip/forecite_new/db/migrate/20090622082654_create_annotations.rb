class CreateAnnotations < ActiveRecord::Migration
  def self.up
    create_table :annotations , :options => 'default charset=utf8'  do |t|
	  t.string :type
	  t.string :anno_key
	  t.text :text
	  t.integer :paper_id
	  t.integer :user_id
	  t.integer :from_word
	  t.integer :to_word
      t.timestamps
    end
  end

  def self.down
    drop_table :annotations
  end
end
