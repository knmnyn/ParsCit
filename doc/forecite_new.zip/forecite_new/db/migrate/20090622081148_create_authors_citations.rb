class CreateAuthorsCitations < ActiveRecord::Migration
  def self.up
    create_table :authors_citations, :options => 'default charset=utf8' do |t|
      t.integer :author_id, :citation_id, :status
    end
  end

  def self.down
    drop_table :authors_citations
  end
end
