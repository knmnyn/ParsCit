class CreateCitations < ActiveRecord::Migration
  def self.up
    create_table :citations, :options => 'default charset=utf8' do |t|
      t.belongs_to :paper # Citation#to_paper

      t.string :address,
               :annote,
               :booktitle,
               :chapter,
               :crossref,
               :edition,
               :eprint,
               :howpublished,
               :institution,
               :journal,
               :key,
               :month,
               :note,
               :number,
               :organization,
               :pages,
               :publisher,
               :school,
               :series,
               :title,
               :tech_type, # Bibtex "type"
               :url,
               :volume,
               :year
      t.integer :order,
				:status
      t.timestamps
    end
  end

  def self.down
    drop_table :citations
  end
end
