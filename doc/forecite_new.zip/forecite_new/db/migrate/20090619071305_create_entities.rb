class CreateEntities < ActiveRecord::Migration
  def self.up
    create_table :entities, :options => 'default charset=utf8' do |t|
      t.belongs_to :person
      t.string :string, :type # Type is for STI
	  t.integer :status
      t.timestamps
    end
  end

  def self.down
    drop_table :entities
  end
end
