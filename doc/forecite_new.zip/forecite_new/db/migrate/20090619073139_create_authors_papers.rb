class CreateAuthorsPapers < ActiveRecord::Migration
  def self.up
    create_table :authors_papers, :options => 'default charset=utf8' do |t|
      t.integer :author_id, :paper_id, :order, :status
    end
  end

  def self.down
    drop_table :authors_papers
  end
end
