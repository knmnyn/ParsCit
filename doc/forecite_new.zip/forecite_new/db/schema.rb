# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20090703145408) do

  create_table "annotations", :force => true do |t|
    t.string   "type"
    t.string   "anno_key"
    t.text     "text"
    t.integer  "paper_id"
    t.integer  "user_id"
    t.integer  "from_word"
    t.integer  "to_word"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "authors_citations", :force => true do |t|
    t.integer "author_id"
    t.integer "citation_id"
    t.integer "status"
  end

  create_table "authors_papers", :force => true do |t|
    t.integer "author_id"
    t.integer "paper_id"
    t.integer "order"
    t.integer "status"
  end

  create_table "authors_presentations", :force => true do |t|
    t.integer "author_id"
    t.integer "presentation_id"
    t.integer "order"
  end

  create_table "citations", :force => true do |t|
    t.integer  "paper_id"
    t.string   "address"
    t.string   "annote"
    t.string   "booktitle"
    t.string   "chapter"
    t.string   "crossref"
    t.string   "edition"
    t.string   "eprint"
    t.string   "howpublished"
    t.string   "institution"
    t.string   "journal"
    t.string   "key"
    t.string   "month"
    t.string   "note"
    t.string   "number"
    t.string   "organization"
    t.string   "pages"
    t.string   "publisher"
    t.string   "school"
    t.string   "series"
    t.string   "title"
    t.string   "tech_type"
    t.string   "url"
    t.string   "volume"
    t.string   "year"
    t.integer  "order"
    t.integer  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "citations_editors", :force => true do |t|
    t.integer "editor_id"
    t.integer "citation_id"
    t.integer "order"
  end

  create_table "columns", :force => true do |t|
    t.integer  "mypage_id"
    t.integer  "l"
    t.integer  "t"
    t.integer  "b"
    t.integer  "r"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "editors_papers", :force => true do |t|
    t.integer "editor_id"
    t.integer "paper_id"
    t.integer "order"
    t.integer "status"
  end

  create_table "entities", :force => true do |t|
    t.integer  "person_id"
    t.string   "string"
    t.string   "type"
    t.integer  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "in_text_citations", :force => true do |t|
    t.integer  "citation_id"
    t.integer  "paper_id"
    t.string   "context"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "ingest_logs", :force => true do |t|
    t.integer  "job_id"
    t.integer  "metadata"
    t.integer  "content"
    t.integer  "paper_id"
    t.string   "filename"
    t.string   "url"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "jobs", :force => true do |t|
    t.string   "origin"
    t.string   "filename"
    t.string   "title"
    t.string   "tags"
    t.string   "tasks"
    t.string   "startTime"
    t.string   "endTime"
    t.integer  "user_id"
    t.integer  "priority"
    t.integer  "status"
    t.integer  "checked"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "libraries", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "mylines", :force => true do |t|
    t.integer  "l"
    t.integer  "t"
    t.integer  "b"
    t.integer  "r"
    t.integer  "para_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "mypages", :force => true do |t|
    t.string   "name"
    t.integer  "w"
    t.integer  "h"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "papers", :force => true do |t|
    t.string   "address"
    t.string   "annote"
    t.string   "booktitle"
    t.string   "chapter"
    t.string   "crossref"
    t.string   "description"
    t.string   "edition"
    t.string   "eprint"
    t.string   "howpublished"
    t.string   "institution"
    t.string   "journal"
    t.string   "key"
    t.string   "md5"
    t.string   "month"
    t.string   "note"
    t.string   "number"
    t.string   "organization"
    t.string   "pages"
    t.string   "publisher"
    t.string   "school"
    t.string   "series"
    t.string   "title"
    t.string   "title_lower"
    t.string   "tech_type"
    t.string   "urls"
    t.string   "volume"
    t.string   "year"
    t.text     "text"
    t.integer  "last_modified_by"
    t.integer  "level_access"
    t.integer  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "papers_mypages", :force => true do |t|
    t.integer  "paper_id"
    t.integer  "mypage_id"
    t.integer  "order"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "paras", :force => true do |t|
    t.integer  "column_id"
    t.integer  "l"
    t.integer  "t"
    t.integer  "b"
    t.integer  "r"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "paras_slides", :id => false, :force => true do |t|
    t.integer "para_id"
    t.integer "slide_id"
  end

  create_table "people", :force => true do |t|
    t.string   "first_name"
    t.string   "middle_name"
    t.string   "last_name"
    t.string   "affiliation"
    t.string   "email"
    t.string   "telephone"
    t.string   "web_address"
    t.string   "designation"
    t.string   "street_address"
    t.string   "city"
    t.string   "state"
    t.integer  "zip"
    t.integer  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "presentations", :force => true do |t|
    t.string   "address"
    t.string   "institution"
    t.string   "organization"
    t.string   "note"
    t.string   "title"
    t.string   "urls"
    t.string   "slide_images_path"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.datetime "date"
    t.datetime "#<ActiveRecord::ConnectionAdapters::TableDefinition:0xb75a7a14>"
  end

  create_table "presentations_presenters", :force => true do |t|
    t.integer "presenter_id"
    t.integer "presentation_id"
    t.integer "order"
  end

  create_table "rights", :force => true do |t|
    t.string   "name"
    t.string   "controller"
    t.string   "action"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "rights_roles", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "roles", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "roles_users", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sessions", :force => true do |t|
    t.string   "session_id", :default => "", :null => false
    t.text     "data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sessions", ["session_id"], :name => "index_sessions_on_session_id"
  add_index "sessions", ["updated_at"], :name => "index_sessions_on_updated_at"

  create_table "slides", :force => true do |t|
    t.integer  "presentation_id"
    t.string   "title"
    t.string   "image_name"
    t.string   "urls"
    t.text     "text"
    t.integer  "position"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tiddlers", :force => true do |t|
    t.string   "uniqid"
    t.string   "modifier"
    t.string   "title"
    t.string   "tags"
    t.string   "tasks"
    t.string   "localfile"
    t.string   "url"
    t.string   "created"
    t.string   "modified"
    t.text     "note"
    t.integer  "paper_id"
    t.integer  "fcreader"
    t.integer  "changecount"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.integer  "person_id"
    t.string   "login"
    t.string   "hashed_password"
    t.string   "salt"
    t.string   "activation_code"
    t.string   "temp_pass"
    t.integer  "active"
    t.integer  "temp_pass_active"
    t.integer  "use_image"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "words", :force => true do |t|
    t.string   "word"
    t.integer  "l"
    t.integer  "t"
    t.integer  "b"
    t.integer  "r"
    t.integer  "myline_id"
    t.integer  "mypage_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
