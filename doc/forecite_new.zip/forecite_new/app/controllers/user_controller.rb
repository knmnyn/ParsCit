class UserController < ApplicationController

	def profile
	
	end

	def login
		if request.post?
			session[:user_id] = nil
			user = User.authenticate(params[:user][:login], params[:user][:password])
			if user
				if user.active == 1
					session[:user_id] = user.id
				else
					flash[:notice] = "This account has not been activated. Please activate before log in"
				end
			else
			 	flash[:notice] = "Login failed"
			end
			redirect_to :controller => "forecite", :action => "index"
		end
	end

	def logout
		session[:user_id] = nil
		redirect_to :controller => "forecite", :action => "index"
	end

	def register
		@user = User.new(params[:user])

		if request.post?
			@temp = Person.find_by_email(@user.login)
			if @temp == nil
				p_hash = Hash.new
				p_hash['email'] = @user.login
				@temp = Person.new(p_hash)
				@temp.save
			end

			@user.activation_code = UserController.random_string(32)
			@user.person_id = @temp.id
			@user.save

			role = Role.find_by_name("UntrustedUser")
			role.users << @user
			flash[:notice] = "Account registered. Please check your email for details on how to activate it"
			redirect_to :controller => "forecite", :action => "index"
		end
	end

	def activate
		user = params[:id].blank? ? false : User.find_by_activation_code(params[:id])
		if user and user.active != 1
			user.active = 1
			if user.save
				redirect_to :action => "login"
			end
		else
			redirect_to :controller => "forecite", :action => "index"
		end
	
	end

	def self.random_string(len)
		chars = ("a".."z").to_a + ("0".."9").to_a
		result = ""
		1.upto(len){|i| result << chars[rand((chars.size) -1)]}
		result
	end

end
