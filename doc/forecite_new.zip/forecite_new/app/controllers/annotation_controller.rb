class AnnotationController < ApplicationController

	def addAnchor

	end

	def delAnchor

	end

	def addNote

	end

	def delNote

	end

	def listAnchor

	end

	def listNote

	end

	def listPageNote
	
	end

	def listKeyword

	end
end
