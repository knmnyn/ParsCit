class ForeciteController < ApplicationController
	#define all the path information for the application
	PATH = "/myror/forecite/forecite_new"
	PAPER_PATH = "http://aye.comp.nus.edu.sg/~forecite/static/forecite_papers"
	PAPER_DIR = "/home/forecite/public_html/static/forecite_papers"
	FCN = "http://aye.comp.nus.edu.sg/~nguyentd/forecitenote/forecitenote.php"

	#ForeCite homepage
	def index  

	end

end
