class DataController < ApplicationController
end
