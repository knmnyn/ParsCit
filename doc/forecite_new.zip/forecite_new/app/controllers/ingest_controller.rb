class IngestController < ApplicationController

	def ingest
		origin = params[:origin]
		filename = params[:filename]
		tags = params['tags']
		tasks = params['tasks']
		user_id = params['user_id']

		cmd = "mv /home/forecite/public_html/forecitenote/upload/#{filename} #{RAILS_ROOT}/tmp/#{filename}"
		system(cmd)
		
		cmd = "vendor/ingest/ingest.rb '' '#{filename}' '#{tasks}' '#{tags}' >> output.txt &"
		system(cmd)
		
		render :text => "Ingestion for #{origin} has been submitted"
	end

	def ingestPDF
		title = params[:title]
		modifier = params[:modifier]
		origin = params[:origin]
		time = Time.new.to_i
		user = User.find_by_login(modifier)

		filename = "#{user.id}_#{time}_#{origin}"
		cmd = "mv /home/forecite/public_html/forecitenote/upload/#{params[:filename]} #{RAILS_ROOT}/tmp/#{filename}"
		system(cmd)
		cmd = "vendor/ingest/ingest.rb '#{title}' '#{filename}' '' '' >> output.txt &"
		system(cmd)
		render :text  => "Ingestion job for #{origin} has been submitted"
	end
	
	def ingestTitle

	end

	def ingestURL

	end
end
