class PaperController < ApplicationController

	#search for paper
	def search
		if request.post?
			session[:title] = params[:title]
		end
		@papers = Paper.search(session[:title],params[:page])	
	end

	#show paper metadata
	def viewMetadata
		@paper = Paper.find_by_id(params[:id])
		@refs  = @paper.citations
	end

	#show paper content
	def viewContent
		@paper = Paper.find_by_id(params[:id])
		@pages = @paper.pages
		@path  = @paper.getHTMLPath()
		
	end
	
	def download
	    @paper = Paper.find(params[:id])
		@path = @paper.getPath()
		@name = @paper.getName()
	
	    send_file("#{@path}/#{@name}.pdf" ,
	      :disposition => 'attachment',
	      :encoding => 'utf8', 
	      :type => "application/pdf",
	      :filename => URI.encode(@name)) 
	end

	
end
