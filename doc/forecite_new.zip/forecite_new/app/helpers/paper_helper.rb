module PaperHelper
end
