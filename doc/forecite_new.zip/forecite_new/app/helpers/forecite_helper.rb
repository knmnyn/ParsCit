module ForeciteHelper
end
