class Tag < Annotation
end
