class EditorsPapers < ActiveRecord::Base
  belongs_to :editor
  belongs_to :paper
end
