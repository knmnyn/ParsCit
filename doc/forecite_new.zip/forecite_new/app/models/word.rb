class Word < ActiveRecord::Base
	belongs_to :myline
	belongs_to :mypage

end
