class InTextCitation < ActiveRecord::Base
  belongs_to :citation
  belongs_to :paper
end
