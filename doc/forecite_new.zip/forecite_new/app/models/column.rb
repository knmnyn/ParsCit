class Column < ActiveRecord::Base
	belongs_to :mypage
	has_many :paras
end
