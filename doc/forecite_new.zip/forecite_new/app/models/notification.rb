class Notification < ActiveRecord::Base
	belongs_to :job
	belongs_to :paper
end
