class Name
	attr_reader :first, :middle, :last

	def initialize(first, middle, last)
		@first = first
		@middle = middle
		@last = last
	end
	
	def to_s
		[ @first, @middle, @last ].compact.join(" ")
	end
end

class Address
  def initialize(street_address, city, state, zip)
    @street_address  = street_address
    @city = city
    @state = state
    @zip = zip
  end

  attr_reader :street_address, :city, :state, :zip
end

class Person < ActiveRecord::Base
  has_many :entities
  has_one :user

	composed_of :name, :class_name => "Name",
		:mapping => [[:first_name, :first],
			           [:middle_name, :middle],
			           [:last_name, :last]]

  composed_of :address, :class_name => "Address",
    :mapping => [[:street_address, :street_address],
                 [:city, :city],
                 [:state, :state],
                 [:zip, :zip]]

  def hasName
	if ((first_name != nil and first_name != "") or (middle_name != nil and middle_name != "") or (last_name != nil and last_name != ""))
		return true
	end
	return false
  end
end
