class AuthorsPapers < ActiveRecord::Base
	belongs_to :author
	belongs_to :paper
end
