class AuthorsCitations < ActiveRecord::Base
  belongs_to :author
  belongs_to :citation

  def self.find_by_author_citation (author_id, citation_id)
	ac = AuthorsCitations.find(:first, :conditions => ['author_id = ? and citation_id = ?',author_id, citation_id])
  end

end
