class CitationsEditors < ActiveRecord::Base
  belongs_to :citation
  belongs_to :editor
end
