class Paper < ActiveRecord::Base
  DEDUPLICATED = 0
  PROCESSING = 1
  UNTRUSTED = 2
  NOT_DEDUPLICATED = 3
  MANUAL_CHECKED = 4
  TEMPORARY =  5
  
  PRIVATE = 0
  GROUP = 1
  PUBLIC = 2

  has_many :to_citations,
    :class_name => 'Citation'

  has_many :papers_mypages,
  	:class_name => 'PapersMypages'
  has_many :mypages,
  	:through => :papers_mypages

  has_many :in_text_citations
  has_many :citations,
    :through => :in_text_citations

  has_many :authors_papers,
    :class_name => 'AuthorsPapers'
  has_many :authors,
    :through => :authors_papers
  
  has_many :editors_papers,
    :class_name => 'EditorsPapers'
  has_many :editors,
    :through => :editors_papers

  has_many :libraries
  has_many :users,
    :through => :libraries

  has_many :annotations

  serialize :urls, Array

  def getHTMLPath
	@path = ForeciteController::PAPER_PATH
	count = 0
	@LEVEL = 4
	while count < @LEVEL do
		startIndex = count*2
		endIndex = startIndex + 1
		@path = @path + "/" + md5[startIndex..endIndex]
		count = count + 1
	end
	@path
  end


  def getPath
	@path = ForeciteController::PAPER_DIR
	count = 0
	@LEVEL = 4
	while count < @LEVEL do
		startIndex = count*2
		endIndex = startIndex + 1
		@path = @path + "/" + md5[startIndex..endIndex]
		count = count + 1
	end
	@path
  end

  def getName
  	@LEVEL = 4
	startIndex = @LEVEL*2
	endIndex = md5.length() -1
	@name = md5[startIndex..endIndex]
	@name
  end
  
  def hasAuthorInfo
	if authors != nil and authors.length > 0
		return true
	end
	return false
  end
  
  def getAuthors
  	result = ""
	if authors != nil
		for author in authors do
			result += author.string + ", "
		end
		endIndex = result.length - 3
		result = result[0..endIndex]
	end
	result
  end
  
  def getKeywords()
	 @tags = Tag.find(:all, :conditions => ['paper_id = ?', "#{self.id}"])
	 result = ""	
	 for tag in @tags do
	 	
		result += " " + tag.text + ","
	 end
	 result.chop
  end
 
  def getBibtex()
	#get bibtex key : first author last_name + year + first 2 words of title
	tab = "&nbsp;&nbsp;&nbsp;"
	if tech_type and tech_type != ""
		tt = tech_type.upcase
	else 
		tt = "MISC"
	end
	bib = "@" +  tt + "{"
	if(authors != nil and authors.length > 0)
		author = authors[0]
		if(author.string.strip != "")
		a_temp = author.string.split(' ')
		bib += a_temp.pop
		end
	else
		bib += "_"
	end

	if (year != nil and year.length == 4)
		bib += year[2..3]
	else
		bib += "_"
	end
	
	a_title = title.split(' ')
	count = 0
	while (count < 2 and count < a_title.length)
		bib += a_title.fetch(count)
		count += 1
	end
	
	bib += ",<br/>" + tab + "author = {"
	if authors != nil and authors.length > 0
		for author in authors do
			bib += author.string + ", "
		end
		bib = bib.strip()
		pos = bib.length - 2
		bib = bib[0..pos]
	end
	bib += "},<br/>"

	if editors != nil and editors.length > 0
	
		bib += "" + tab + "editor = {"
		for editor in editors do
			bib += editor.string + ", "
		end
		bib = bib.strip()
		pos = bib.length - 2
		bib = bib[0..pos]
		bib = "},<br/>"
	end

	bib += tab + "title = {" + title + "}, <br/>"
	@pages = ""

	case tt
		when "MISC": bib += tab + "year = {" + "#{year == nil ? "" : year}" + "}<br/>"
		when "ARTICLE": bib += tab + "journal = {" + "#{journal == nil ? "" : journal}" + "},<br/>" + tab + "year = {" + "#{year == nil ? "" : year}" + "},<br/>" + tab + "volume = {" + "#{volume == nil ? "" : volume}" + "}<br/>}"
		when "BOOK": bib += tab + "publisher = {" + "#{publisher == nil ? "" : publisher}" + "},<br/>" + tab + "year = {" + "#{year == nil ? "" : year}" + "}<br/>" 
		when "CONFERENCE": bib+=tab + "booktitle = {" + "#{booktitle == nil ? "" : booktitle}" + "},<br/>" + tab + "year = {" + "#{year ==  nil ? "" : year}" + "}<br/>"
		when "INCOLLECTION": bib+=tab + "booktitle = {" + "#{booktitle == nil ? "" : booktitle}" + "},<br/>" + tab + "year = {" + "#{year ==  nil ? "" : year}" + "}<br/>"
		when "INPROCEEDINGS": bib +=tab +  "booktitle = {" + "#{booktitle == nil ? "" : booktitle}" + "},<br/>" + tab + "year = {" + "#{year == nil ? "" : year}" + "},<br/>" + tab + "pages = {" + "#{@pages}" + "}<br/>}"
		when "MASTERSTHESIS": bib += tab + "school = {" + "#{school == nil ? "" : school}" + "},<br/>" + tab + "year = {" + "#year == nil : "" : year}" + "}<br/>"
		when "PHDTHESIS": bib += tab + "school = {" + "#{school == nil ? "" : school}" + "},<br/>" + tab + "year = {" + "#year == nil : "" : year}" + "}<br/>"
		when "PROCEEDINGS": bib += tab + "publisher = {" + "#{publisher == nil ? "" : publisher}" + "},<br/>" + tab + "year = {" + "#{year == nil ? "" : year}" + "}<br/>" 
		when "TECHREPORT" : bib += tab + "institution = {" + "#{institution == nil ? "" : institution}" + "},<br/>" + tab + "year = {" + "#{year == nil ? "" : year}" + "}<br/>}" 
	end
  	bib = bib + "}"

  end

 
  #search function 
  def self.search(search, page)
	paginate :per_page => 10, :page => page,
			 :conditions => ['match(title) against (? in boolean mode) and status = ?', "+\"#{search}\"","#{Paper::NOT_DEDUPLICATED}"]

  end

  def cited_by
    citations =  self.to_citations
    unless citations.empty?
      citations.collect! { |cit| cit.papers }
      citations.flatten
    else
      []
    end
  end

  # Overload authors, editors method to enforce ordering
  #def authors
  #  "not yet implemented"
  #end
  #def editors
  #  "not yet implemented"
  #end

end
