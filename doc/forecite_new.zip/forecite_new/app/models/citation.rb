class Citation < ActiveRecord::Base
  belongs_to :to_paper,
    :class_name => 'Paper',
    :foreign_key => 'paper_id'
  has_many :in_text_citations
  has_many :papers,
    :through => :in_text_citations

  has_many :authors_citations,
    :class_name => 'AuthorsCitations'
  has_many :authors,
    :through => :authors_citations
	has_many :citations_editors,
    :class_name => 'CitationsEditors'
  has_many :editors,
    :through => :citations_editors

  def variants
    paper = self.to_paper
    unless paper.nil?
      paper.to_citations.reject { |cit| cit == self }
    else
      []
    end
  end
  
  # Overload authors, editors method to enforce ordering
  #def authors
  #  "not yet implemented"
  #end
  #def editors
  #  "not yet implemented"
  #end
end
