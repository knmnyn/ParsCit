class Presentation < ActiveRecord::Base
  has_many :slides

	has_many :authors_presentations,
    :class_name => 'AuthorsPresentations'
  has_many :authors,
    :through => :authors_presentations
	has_many :presentations_presenters,
    :class_name => 'PresentationsPresenters'
  has_many :presenters,
    :through => :presentations_presenters

  serialize :urls, Array


  # Overload authors, editors method to enforce ordering
  def authors
    "not yet implemented"
  end
  def presenters
    "not yet implemented"
  end
end
