class Author < Entity
  has_many :authors_papers,
    :class_name => 'AuthorsPapers'
  has_many :papers,
    :through => :authors_papers

  has_many :authors_presentations,
    :class_name => 'AuthorsPresentations'
  has_many :presentations,
    :through => :authors_presentations

  has_many :authors_citations,
    :class_name => 'AuthorsCitations'
  has_many :citations,
    :through => :authors_citations
end
