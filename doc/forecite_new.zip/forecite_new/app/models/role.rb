class Role < ActiveRecord::Base
	has_many :rights_roles, :class_name => "RightsRoles"
	has_many :rights, :through => :rights_roles
	
	has_many :roles_users, :class_name => "RolesUsers"
	has_many :users, :through => :roles_users
end
