class Anchor < Annotation
end
