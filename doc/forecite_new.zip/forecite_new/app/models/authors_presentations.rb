class AuthorsPresentations < ActiveRecord::Base
  belongs_to :author
  belongs_to :presentation
end
