class ParasSlides < ActiveRecord::Base
end
