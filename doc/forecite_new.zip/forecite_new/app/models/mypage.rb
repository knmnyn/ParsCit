class Mypage < ActiveRecord::Base
	has_many :papers_mypages,
		:class_name => 'PapersMyPages'
	has_many :papers,
		:through => :papers_mypages
	has_many :columns
	has_many :words	
end
