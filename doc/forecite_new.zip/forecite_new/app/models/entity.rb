class Entity < ActiveRecord::Base
  belongs_to :person
end
