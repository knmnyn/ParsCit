class Editor < Entity
  has_many :editors_papers,
    :class_name => 'EditorsPapers'
  has_many :papers,
    :through => :editors_papers

  has_many :citations_editors,
    :class_name => 'CitationsEditors'
  has_many :citations,
    :through => :citations_editors
end
