class Myline < ActiveRecord::Base
	belongs_to :para
	has_many :words
end
