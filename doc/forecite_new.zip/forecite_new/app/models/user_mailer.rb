class UserMailer < ActionMailer::Base

	def signup_notification(user)
		@subject = "ForeCite Signup Notification"
		@recipients = user.login
		@from = "forecite@gmail.com"
		@sent_on = Time.now
		@body["user"] = user
	end


end
