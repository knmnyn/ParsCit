require 'digest/md5'
class Tiddler < ActiveRecord::Base

	def self.createEmptyTiddler(text, tasks,tags, paper,user)
		t_hash = Hash.new
		time = Time.now
		t_hash['uniqid'] = time.to_i.to_s
		
		t_hash['paper_id'] = paper.id
		t_hash['modifier'] = user.login

	  	t_hash['title'] = paper.title
		t_hash['note'] = "#{text}"
		t_hash['tags'] =tags
		t_hash['tasks'] = tasks
		t_hash['localfile'] = ""
		
		url = ""
		if(paper.urls != nil and paper.urls.length > 0)
			url = paper.urls[0]
		end
		t_hash['url'] = url
		
		fcreader = 0
		if paper.mypages != nil and paper.mypages.length > 0
			fcreader = paper.mypages.length
		end
		t_hash['fcreader'] = fcreader
		t_hash['changecount'] = 1
		time = time.getutc
		t_hash['created'] = time.strftime("%Y%m%d%H%M")
		t_hash['modified'] = time.strftime("%Y%m%d%H%M")
		tiddler = Tiddler.new(t_hash)
		tiddler.save
		return tiddler.id
	end


end
