require 'digest/md5'
class User < ActiveRecord::Base
  #is_gravtastic :login 
  validates_presence_of :login
  validates_uniqueness_of :login

  attr_accessor :password_confirmation
  validates_confirmation_of :password

  belongs_to :person
  has_many :libraries
  has_many :papers,
    :through => :libraries

  has_many :roles_users,  :class_name => "RolesUsers"
  has_many :roles, :through => :roles_users

  def validate
  	errors.add_to_base("Missing password") if hashed_password.blank?
  end

  def self.authenticate(login, password)
	user = self.find_by_login(login)
	if user
		expected_password = encrypted_password(password)
		if user.hashed_password != expected_password
			user = nil
		end
	end
	user

  end

  def password
  	@password
  end

  def password=(pwd)
	@password = pwd
	return if pwd.blank?
	self.hashed_password = User.encrypted_password(self.password)
  end

  private

  def self.encrypted_password(password)
	Digest::MD5.hexdigest(password)
  end

end
