class UserObserver < ActiveRecord::Observer
	def after_save(user)
		UserMailer.deliver_signup_notification(user)
	end

end
