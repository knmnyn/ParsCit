class Note < Annotation
end
