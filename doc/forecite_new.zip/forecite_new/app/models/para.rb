class Para < ActiveRecord::Base
end
