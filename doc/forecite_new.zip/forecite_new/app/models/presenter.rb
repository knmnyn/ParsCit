class Presenter < Entity
  has_many :presentations_presenters,
    :class_name => 'PresentationsPresenters'
  has_many :presentations,
    :through => :presentations_presenters
end
