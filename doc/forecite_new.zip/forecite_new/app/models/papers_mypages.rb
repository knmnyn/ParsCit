class PapersMypages < ActiveRecord::Base
	belongs_to :paper
	belongs_to :mypage
end
