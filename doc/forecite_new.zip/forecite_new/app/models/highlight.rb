class Highlight < Annotation
end
