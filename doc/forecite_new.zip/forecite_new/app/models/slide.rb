class Slide < ActiveRecord::Base
  belongs_to :presentation
  has_and_belongs_to_many :paragraphs

  serialize :urls, Array

  def image_path
    presentation = self.presentation
    path = presentation.slide_images_path unless presentation.nil?
    image_name = self.image_name
    unless path.nil? or image_name.nil?
      path + image_name
    else
      nil
    end
  end
end
