require 'test_helper'

class UserMailerTest < ActionMailer::TestCase
  tests UserMailer
  # replace this with your real tests
  def test_truth
    assert true
  end
end
